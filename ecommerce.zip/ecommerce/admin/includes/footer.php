<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2018 Brought To You By<a href="https://code-projects.org/">Code-Projects</a></strong>
</footer>